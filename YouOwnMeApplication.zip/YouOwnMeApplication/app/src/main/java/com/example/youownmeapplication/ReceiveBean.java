package com.example.youownmeapplication;

import java.io.Serializable;

public class ReceiveBean implements Serializable,Comparable<ReceiveBean> {
    private String year;
    private String month;
    private String day;
    private String name;
    private String money;
    private String reason;

    public ReceiveBean(String year,String month,String day,String name,String money,String reason){
        this.year = year;
        this.month = month;
        this.day = day;
        this.name = name;
        this.money = money;
        this.reason = reason;
    }

    public String getYear() {
        return year;
    }

    public String getMonth() {
        return month;
    }

    public String getDay() {
        return day;
    }

    public String getReason() {
        return reason;
    }

    public String getName() {
        return name;
    }

    public String getMoney() {
        return money;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setMoney(String money) {
        this.money = money;
    }


    @Override
    public int compareTo(ReceiveBean o) {
        return Integer.parseInt(year);
    }
}
