package com.example.youownmeapplication;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CalendarView;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;

public class HomeFragment extends Fragment {
    public static int sYear;
    public static int sMonth;
    public static int sDay;
    private SendDataBank sDataBank;
    private ReceiveDataBank rDataBank;
    private View view;
    private ImageButton search_button;
    private ImageButton tongji_button;
    private ArrayList<SendBean> sBeans;
    private ArrayList<ReceiveBean> rBeans;

    public HomeFragment() {
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_home, container, false);
        search_button = view.findViewById(R.id.search_button);
        tongji_button = view.findViewById(R.id.tongji_button);
        /*点击搜索按钮跳转到SearchActivity，同时把sBeans和rBeans传过去*/
        search_button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), SearchActivity.class);
                intent.putExtra("sbeans",sBeans);
                intent.putExtra("rbeans",rBeans);
                startActivity(intent); //点击搜索键跳转到SearchActivity
            }
        });
        /*点击统计按钮跳转到TongJiActivity，同时把sBeans和rBeans传过去*/
        tongji_button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), TongJiActivity.class);
                intent.putExtra("sbeans",sBeans);
                intent.putExtra("rbeans",rBeans);
                startActivity(intent); //点击搜索键跳转到SearchActivity
            }
        });
        /*默认时间是当前时间，如果点击了日历才会改变这个日期*/
        Calendar ca = Calendar.getInstance();
        sYear = ca.get(Calendar.YEAR);
        sMonth = ca.get(Calendar.MONTH)+1;
        sDay = ca.get(Calendar.DAY_OF_MONTH);

        sDataBank =new SendDataBank(this.getContext());
        sDataBank.Load();
        sBeans = sDataBank.getBeans();
        rDataBank =new ReceiveDataBank(this.getContext());
        rDataBank.Load();
        rBeans = rDataBank.getBeans();
        showEvent();
        return view;
    }

    private void showEvent(){
        /*加载随礼和收礼的databank*/

        CalendarView calendarView = view.findViewById(R.id.calendarView3);
        TextView event = view.findViewById(R.id.text_view_event);
        /*给日历设置监听事件*/
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                sYear = year;
                sMonth = month+1; //安卓的月是从0开始的，所以month要+1才是正确的月份
                sDay = dayOfMonth;
                Toast.makeText(getActivity(),"您选择的时间是："+ year + "年" + sMonth + "月" + dayOfMonth + "日",Toast.LENGTH_SHORT).show(); //选择日期时提示用户选择的日期是什么
                StringBuffer string = new StringBuffer();
                /*将选择的日期当天收礼或随礼的记录显示到event*/
                for(int i=0;i<sBeans.size();i++){
                    if(sBeans.get(i).getYear().equals(sYear+"年") && sBeans.get(i).getMonth().equals(sMonth+"") && sBeans.get(i).getDay().equals(sDay+"")){
                        string.append("随礼："+sBeans.get(i).getName()+"------￥"+sBeans.get(i).getMoney()+"元").append("\r\n");
                    }
                }
                for(int j=0;j<rBeans.size();j++){
                    if(rBeans.get(j).getYear().equals(sYear+"") && rBeans.get(j).getMonth().equals(sMonth+"") && rBeans.get(j).getDay().equals(sDay+"")){
                        string.append("收礼："+rBeans.get(j).getName()+"------￥"+rBeans.get(j).getMoney()+"元").append("\r\n");
                    }
                }
                event.setText(string);
            }
        });
    }
}