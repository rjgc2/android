package com.example.youownmeapplication;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import static android.app.Activity.RESULT_OK;

public class ReceiveFragment extends Fragment {
    private ReceiveDataBank dataBank;
    private MyListViewAdapter adapter;

    private static final int CONTEXT_MENU_ITEM_UPDATE = 1;
    private static final int CONTEXT_MENU_ITEM_DELETE = CONTEXT_MENU_ITEM_UPDATE+1;

    private static final int REQUEST_CODE_UPDATE_CAT = 101;

    public ReceiveFragment() { }

    /*创建上下文菜单*/
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        if(v==this.getActivity().findViewById(R.id.list)) {
            menu.setHeaderTitle("操作");
            menu.add(1, CONTEXT_MENU_ITEM_UPDATE, 1, "修改");
            menu.add(1, CONTEXT_MENU_ITEM_DELETE, 1, "删除");
        }
    }

    /*将databank中对应选择的位置的数据修改为update传过来的数据*/
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        switch (requestCode) {
            case REQUEST_CODE_UPDATE_CAT:
                if (resultCode == RESULT_OK) {
                    String name = data.getStringExtra("runame1");
                    String money = data.getStringExtra("rumoney1");
                    String reason = data.getStringExtra("rureason1");
                    String year = data.getStringExtra("ruyear1");
                    String month = data.getStringExtra("rumonth1");
                    String day = data.getStringExtra("ruday1");
                    int position=data.getIntExtra("ruposition1",0);
                    dataBank.getBeans().get(position).setName(name);
                    dataBank.getBeans().get(position).setMoney(money);
                    dataBank.getBeans().get(position).setReason(reason);
                    dataBank.getBeans().get(position).setYear(year);
                    dataBank.getBeans().get(position).setMonth(month);
                    dataBank.getBeans().get(position).setDay(day);
                    dataBank.Save();
                    adapter.notifyDataSetChanged(); //通知适配器进行更新，否则修改之后数据的显示不会自己改变
                }
                break;

            default:

        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    /*对选择的上下文菜单进行操作*/
    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        AdapterView.AdapterContextMenuInfo menuInfo = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        Intent intent;
        final int position=menuInfo.position;
        switch(item.getItemId())
        {
            /*如果点击了修改，则将数据传给ReceiveUpdateActivity并跳转*/
            case CONTEXT_MENU_ITEM_UPDATE:
                intent = new Intent(this.getContext(), ReceiveUpdateActivity.class);
                intent.putExtra("ruposition",position);
                intent.putExtra("runame",dataBank.getBeans().get(position).getName());
                intent.putExtra("rumoney",dataBank.getBeans().get(position).getMoney());
                intent.putExtra("rureason",dataBank.getBeans().get(position).getReason());
                intent.putExtra("ruyear",dataBank.getBeans().get(position).getYear());
                intent.putExtra("rumonth",dataBank.getBeans().get(position).getMonth());
                intent.putExtra("ruday",dataBank.getBeans().get(position).getDay());
                startActivityForResult(intent, REQUEST_CODE_UPDATE_CAT);
                break;
                /*如果点击了删除，则弹出询问对话框询问用户是否确定删除*/
            case CONTEXT_MENU_ITEM_DELETE:
                AlertDialog.Builder builder = new AlertDialog.Builder(this.getContext());
                builder.setTitle("询问");
                builder.setMessage("你确定要删除吗？");
                builder.setCancelable(true);
                /*如果点击确定，则将databank中对应position的记录删除，并通知适配器更新*/
                builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dataBank.getBeans().remove(position);
                        dataBank.Save();
                        adapter.notifyDataSetChanged();
                        /*如果databank没有记录，则提示用户没有收礼记录*/
                        if(0==dataBank.getBeans().size())
                        {
                            Toast.makeText(getContext(),"没有收礼记录！",Toast.LENGTH_SHORT).show();
                        }
                    }
                });  //正面的按钮（肯定）
                builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                }); //反面的按钮（否定)
                builder.create().show();


                break;
            default:
                break;
        }
        return super.onContextItemSelected(item);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_receive, container, false);
        initData();
        initView(view);
        return view;
    }

    private void initView(View view) {
        adapter = new MyListViewAdapter(this.getContext(), R.layout.item_receive,  dataBank.getBeans());

        ListView listView=view.findViewById(R.id.list);
        listView.setAdapter(adapter);

        this.registerForContextMenu(listView);
    }

    private void initData() {
        dataBank=new ReceiveDataBank(this.getContext());
        dataBank.Load();
        /*如果databank没有记录，则提示用户没有收礼记录*/
        if(0==dataBank.getBeans().size())
        {
            Toast.makeText(getContext(),"没有收礼记录！",Toast.LENGTH_SHORT).show();
        }
    }

    class MyListViewAdapter extends ArrayAdapter<ReceiveBean> {
        private int resourceId;

        public MyListViewAdapter(@NonNull Context context, int resource, @NonNull ArrayList<ReceiveBean> objects) {
            super(context, resource,objects);
            this.resourceId=resource;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            ReceiveBean receiveBean = getItem(position);//获取当前项的实例
            View view;
            if(null==convertView)
                view = LayoutInflater.from(getContext()).inflate(this.resourceId, parent, false);
            else
                view=convertView;
            ((TextView) view.findViewById(R.id.text_view_name)).setText(receiveBean.getName());
            ((TextView) view.findViewById(R.id.text_view_reason)).setText(receiveBean.getReason());
            ((TextView) view.findViewById(R.id.text_view_money)).setText("￥"+receiveBean.getMoney()+"元");
            String str = receiveBean.getYear()+"/"+receiveBean.getMonth()+"/"+receiveBean.getDay();
            ((TextView) view.findViewById(R.id.text_view_date)).setText(str);
            return view;
        }
    }
}