package com.example.youownmeapplication;
import android.content.Context;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class SendDataBank {
    private ArrayList<SendBean> arrayListSendBeans = new ArrayList<>();
    private Context context;
    public SendDataBank(Context context)
    {
        this.context=context;
    }
    public ArrayList<SendBean> getBeans() {
        return arrayListSendBeans;
    }
    /*保存的数据都存在sendBean.txt*/
    public void Save()
    {
        ObjectOutputStream oos = null;
        try {
            oos = new ObjectOutputStream(context.openFileOutput("sendBean.txt",Context.MODE_PRIVATE));
            oos.writeObject(arrayListSendBeans);
            oos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /*从sendBean.txt加载数据*/
    public void Load()
    {
        ObjectInputStream ois = null;
        arrayListSendBeans =new ArrayList<>();
        try {
            ois = new ObjectInputStream(context.openFileInput("sendBean.txt"));
            arrayListSendBeans = (ArrayList<SendBean>) ois.readObject();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
