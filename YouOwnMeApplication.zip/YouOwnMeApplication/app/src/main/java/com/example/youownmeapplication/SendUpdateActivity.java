package com.example.youownmeapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

public class SendUpdateActivity extends AppCompatActivity {
    private int grouppst,childpst;
    private String name;
    private String money;
    private String month;
    private String day;
    private EditText editTextName;
    private EditText editTextMoney;
    private EditText editTextMonth;
    private EditText editTextDay;
    ImageButton back_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_update);
        getSupportActionBar().hide(); //隐藏标题栏

        /*获得sendfragment传过来的值*/
        grouppst= getIntent().getIntExtra("sugrouppst",0);
        childpst = getIntent().getIntExtra("suchildpst",0);
        name =getIntent().getStringExtra("suname");
        money = getIntent().getStringExtra("sumoney");
        month = getIntent().getStringExtra("sumonth");
        day = getIntent().getStringExtra("suday");

        editTextName = SendUpdateActivity.this.findViewById(R.id.edit_text_name);
        editTextMoney= SendUpdateActivity.this.findViewById(R.id.edit_text_money);
        editTextMonth= SendUpdateActivity.this.findViewById(R.id.edit_text_month);
        editTextDay= SendUpdateActivity.this.findViewById(R.id.edit_text_day);
        back_button = (ImageButton)findViewById(R.id.tongji_button);
        /*如果点击返回按钮则返回到MainActivity*/
        back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SendUpdateActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        /*将输入框的文本设置为从intent获得的值*/
        editTextName.setText(name);
        editTextMoney.setText(money);
        editTextMonth.setText(month);
        editTextDay.setText(day);

        /*点击确定按钮，向intent里传值，并返回到MainActivity*/
        Button buttonOk = (Button)findViewById(R.id.receive_update_ok_button);
        buttonOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.putExtra("sugrouppst1",grouppst);
                intent.putExtra("suchildpst1",childpst);
                intent.putExtra("suname1", editTextName.getText().toString());
                intent.putExtra("sumoney1",editTextMoney.getText().toString());
                intent.putExtra("sumonth1",editTextMonth.getText().toString());
                intent.putExtra("suday1",editTextDay.getText().toString());
                setResult(RESULT_OK, intent);

                finish();
            }
        });
    }
}