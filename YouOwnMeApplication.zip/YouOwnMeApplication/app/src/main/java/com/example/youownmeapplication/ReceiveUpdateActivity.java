package com.example.youownmeapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

public class ReceiveUpdateActivity extends AppCompatActivity {
    private int position;
    private String name;
    private String money;
    private String reason;
    private String year;
    private String month;
    private String day;
    private EditText editTextName;
    private EditText editTextMoney;
    private EditText editTextReason;
    private EditText editTextYear;
    private EditText editTextMonth;
    private EditText editTextDay;
    ImageButton back_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receive_update);
        getSupportActionBar().hide(); //隐藏标题栏

        /*获得receivedfragment传过来的值*/
        position = getIntent().getIntExtra("ruposition",0);
        name =getIntent().getStringExtra("runame");
        money = getIntent().getStringExtra("rumoney");
        reason = getIntent().getStringExtra("rureason");
        year = getIntent().getStringExtra("ruyear");
        month = getIntent().getStringExtra("rumonth");
        day = getIntent().getStringExtra("ruday");

        editTextName = ReceiveUpdateActivity.this.findViewById(R.id.edit_text_name);
        editTextMoney= ReceiveUpdateActivity.this.findViewById(R.id.edit_text_money);
        editTextReason= ReceiveUpdateActivity.this.findViewById(R.id.edit_text_reason1);
        editTextYear= ReceiveUpdateActivity.this.findViewById(R.id.edit_text_year1);
        editTextMonth= ReceiveUpdateActivity.this.findViewById(R.id.edit_text_month1);
        editTextDay= ReceiveUpdateActivity.this.findViewById(R.id.edit_text_day1);
        back_button = (ImageButton)findViewById(R.id.tongji_button);
        /*如果点击返回按钮则返回到MainActivity*/
        back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ReceiveUpdateActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        /*将输入框的文本设置为从intent获得的值*/
        editTextName.setText(name);
        editTextMoney.setText(money);
        editTextReason.setText(reason);
        editTextYear.setText(year);
        editTextMonth.setText(month);
        editTextDay.setText(day);

        /*点击确定按钮，向intent里传值，并返回到MainActivity*/
        Button buttonOk = (Button)findViewById(R.id.receive_update_ok_button);
        buttonOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.putExtra("ruposition1",position);
                intent.putExtra("runame1", editTextName.getText().toString());
                intent.putExtra("rumoney1",editTextMoney.getText().toString());
                intent.putExtra("rureason1",editTextReason.getText().toString());
                intent.putExtra("ruyear1",editTextYear.getText().toString());
                intent.putExtra("rumonth1",editTextMonth.getText().toString());
                intent.putExtra("ruday1",editTextDay.getText().toString());
                setResult(RESULT_OK, intent);

                finish();
            }
        });
    }
}