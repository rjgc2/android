package com.example.youownmeapplication;

import android.content.Context;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class ReceiveDataBank {
    private ArrayList<ReceiveBean> arrayListReceiveBeans = new ArrayList<>();
    private Context context;
    public ReceiveDataBank(Context context)
    {
        this.context=context;
    }
    public ArrayList<ReceiveBean> getBeans() {
        return arrayListReceiveBeans;
    }
    /*保存的数据都存在receiveBean.txt*/
    public void Save()
    {
        ObjectOutputStream oos = null;
        try {
            oos = new ObjectOutputStream(context.openFileOutput("receiveBean.txt",Context.MODE_PRIVATE));
            oos.writeObject(arrayListReceiveBeans);
            oos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /*从receiveBean.txt加载数据*/
    public void Load()
    {
        ObjectInputStream ois = null;
        arrayListReceiveBeans =new ArrayList<>();
        try {
            ois = new ObjectInputStream(context.openFileInput("receiveBean.txt"));
            arrayListReceiveBeans = (ArrayList<ReceiveBean>) ois.readObject();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
