package com.example.youownmeapplication;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;

import static android.app.Activity.RESULT_OK;

public class SendFragment extends Fragment {
    private MyExpandableListViewAdapter adapter;
    private SendDataBank sendDataBank;
    private ArrayList<String> children;
    private ArrayList<Integer> number;
    private ArrayList<ArrayList<SendBean>> beans;
    private ArrayList<SendBean> bean;

    private static final int CONTEXT_MENU_ITEM_UPDATE = 1;
    private static final int CONTEXT_MENU_ITEM_DELETE = CONTEXT_MENU_ITEM_UPDATE+1;

    private static final int REQUEST_CODE_UPDATE = 101;

    public SendFragment() { }

    @Override
    public void onCreateContextMenu(@NonNull ContextMenu menu, @NonNull View v, @Nullable ContextMenu.ContextMenuInfo menuInfo) {
        ExpandableListView.ExpandableListContextMenuInfo info = (ExpandableListView.ExpandableListContextMenuInfo)menuInfo;
        int type = ExpandableListView.getPackedPositionType(info.packedPosition);
        super.onCreateContextMenu(menu, v, menuInfo);

        /*给ExpandableListView的第二级列表创建上下文菜单*/
        if (type == ExpandableListView.PACKED_POSITION_TYPE_CHILD) {
            menu.setHeaderTitle("操作");
            menu.add(1, CONTEXT_MENU_ITEM_UPDATE, 1, "修改");
            menu.add(1, CONTEXT_MENU_ITEM_DELETE, 1, "删除");
        }
    }

    /*将databank中对应选择的位置的数据修改为update传过来的数据*/
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        switch (requestCode) {
            case REQUEST_CODE_UPDATE:
                if (resultCode == RESULT_OK) {
                    String name = data.getStringExtra("suname1");
                    String money = data.getStringExtra("sumoney1");
                    String month = data.getStringExtra("sumonth1");
                    String day = data.getStringExtra("suday1");

                    int grouppst=data.getIntExtra("sugrouppst1",0);
                    int childpst=data.getIntExtra("suchildpst1",0);
                    int position=sendDataBank.getBeans().indexOf(beans.get(grouppst).get(childpst));
                    sendDataBank.getBeans().get(position).setName(name);
                    sendDataBank.getBeans().get(position).setMoney(money);
                    sendDataBank.getBeans().get(position).setMonth(month);
                    sendDataBank.getBeans().get(position).setDay(day);
                    sendDataBank.Save();
                    beans.get(grouppst).get(childpst).setName(name);
                    beans.get(grouppst).get(childpst).setMoney(money);
                    beans.get(grouppst).get(childpst).setMonth(month);
                    beans.get(grouppst).get(childpst).setDay(day);

                    adapter.notifyDataSetChanged(); //通知适配器进行更新
                }
                break;
            default:
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    /*对选择的上下文菜单进行操作*/
    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        ExpandableListView.ExpandableListContextMenuInfo menuInfo = (ExpandableListView.ExpandableListContextMenuInfo) item.getMenuInfo();
        Intent intent;
        final int grouppst = ExpandableListView.getPackedPositionGroup(menuInfo.packedPosition);
        final int childpst = ExpandableListView.getPackedPositionChild(menuInfo.packedPosition);

        switch(item.getItemId())
        {
            /*如果点击了修改，则将数据传给SendUpdateActivity并跳转*/
            case CONTEXT_MENU_ITEM_UPDATE:
                intent = new Intent(this.getContext(), SendUpdateActivity.class);
                intent.putExtra("sugrouppst",grouppst);
                intent.putExtra("suchildpst",childpst);
                intent.putExtra("suname",beans.get(grouppst).get(childpst).getName() );
                intent.putExtra("sumoney",beans.get(grouppst).get(childpst).getMoney() );
                intent.putExtra("sumonth",beans.get(grouppst).get(childpst).getMonth() );
                intent.putExtra("suday",beans.get(grouppst).get(childpst).getDay() );
                startActivityForResult(intent, REQUEST_CODE_UPDATE);
                break;
            /*如果点击了删除，则弹出询问对话框询问用户是否确定删除*/
            case CONTEXT_MENU_ITEM_DELETE:
                AlertDialog.Builder builder = new AlertDialog.Builder(this.getContext());
                builder.setTitle("询问");
                builder.setMessage("你确定要删除吗？");
                builder.setCancelable(true);
                /*如果点击确定，则将databank中对应position的记录删除，并通知适配器更新*/
                builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        sendDataBank.getBeans().remove(beans.get(grouppst).get(childpst));
                        sendDataBank.Save();
                        Integer n = number.get(grouppst)-1;
                        number.remove(grouppst);
                        number.add(grouppst,n);
                        bean.remove(beans.get(grouppst).get(childpst));
                        beans.get(grouppst).remove(childpst);
                        /*如果databank中没有记录了，则在第一级列表添加一个“没有随礼记录”*/
                        if (beans.get(grouppst).size()==0){
                            children.remove(grouppst);
                            number.remove(grouppst);
                            beans.remove(grouppst);
                            if(children.size()==0){
                                children.add("没有随礼记录");
                                number.add(0);
                                bean.add(new SendBean("","","","",""));
                                beans.add(bean);
                            }
                        }
                        adapter.notifyDataSetChanged();
                    }
                });  //正面的按钮（肯定）
                builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                }); //反面的按钮（否定)
                builder.create().show();
                break;
            default:
                break;
        }
        return super.onContextItemSelected(item);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_send, container, false);

        initData();
        initView(view);

        return view;
    }

    /*databank中的年份排序*/
    public ArrayList<String> sorted_by_year(ArrayList<SendBean> beansYear){
        ArrayList<String> str = new ArrayList<>();
        for (int i=0;i<beansYear.size();i++){
            if(!str.contains(beansYear.get(i).getYear())){
                str.add(beansYear.get(i).getYear());
            }
        }
        Collections.sort(str);
        return str;
    }

    private ArrayList<ArrayList<SendBean>> initData(){
        sendDataBank = new SendDataBank(this.getContext());
        sendDataBank.Load();
        beans= new ArrayList<ArrayList<SendBean>>();
        bean = new ArrayList<SendBean>();
        bean= sendDataBank.getBeans();
        children = new ArrayList<String>();
        number = new ArrayList<Integer>();
        /*如果databank中没有记录了，则在第一级列表添加一个“没有随礼记录”*/
        if (bean == null || 0==bean.size()) {
            children.add("没有随礼记录");
            number.add(0);
            bean.add(new SendBean("","","","",""));
            beans.add(bean);
        }
        else {
            children=sorted_by_year(bean);
        }
        /*对databank中的记录逐个进行比对，如果该记录的年份等于第一级列表中的某个年份，则该记录加入到那个年份对应的二级列表中。*/
        for(int i=0;i<children.size();i++){
            ArrayList<SendBean> child = new ArrayList<>();
            for(int j=0;j<bean.size();j++){
                if(children.get(i).equals(bean.get(j).getYear())){
                    child.add(bean.get(j));
                }
            }
            Integer num = child.size();
            number.add(num);
            beans.add(child);
        }
        return beans;
    }

    private void initView(View view){
        ExpandableListView expandableListView=view.findViewById(R.id.exlist);
        adapter = new MyExpandableListViewAdapter(getActivity(),children,number,beans);
        expandableListView.setAdapter(adapter);
        expandableListView.expandGroup(0);
        this.registerForContextMenu(expandableListView);
    }

    class MyExpandableListViewAdapter extends BaseExpandableListAdapter {
        private Context context;
        private ArrayList<String> children;
        private ArrayList<Integer> number;
        private ArrayList<ArrayList<SendBean>> SendBeans;

        public MyExpandableListViewAdapter(Context context,ArrayList<String> children,ArrayList<Integer> number,ArrayList<ArrayList<SendBean>> SendBeans) {
            this.context = context;
            this.children = children;
            this.number = number;
            this.SendBeans = SendBeans;
        }

        @Override
        public int getGroupCount() {
            return children.size();
        }

        @Override
        public int getChildrenCount(int groupPosition) {
            return SendBeans.get(groupPosition).size();
        }

        @Override
        public Object getGroup(int groupPosition) {
            return children.get(groupPosition);
        }

        @Override
        public Object getChild(int groupPosition, int childPosition) {
            return SendBeans.get(groupPosition).get(childPosition);
        }

        @Override
        public long getGroupId(int groupPosition) {
            return groupPosition;
        }

        @Override
        public long getChildId(int groupPosition, int childPosition) {
            return childPosition;
        }

        @Override
        public boolean hasStableIds() {
            return true;
        }

        @Override
        public View getGroupView(int groupPosition, boolean isExpanded,
                                 View convertView, ViewGroup parent) {
            GroupHolder groupHolder;
            if (convertView == null) {

                convertView = (View) getActivity().getLayoutInflater().from(context).inflate(
                        R.layout.father_send, null);
                groupHolder = new GroupHolder();
                groupHolder.txt1 = (TextView) convertView.findViewById(R.id.year_text);
                groupHolder.txt2 = (TextView) convertView.findViewById(R.id.num_text);
                convertView.setTag(groupHolder);
            }
            else {
                groupHolder = (GroupHolder) convertView.getTag();
            }
            groupHolder.txt1.setText(children.get(groupPosition));
            groupHolder.txt2.setText(number.get(groupPosition)+"");
            return convertView;
        }

        @Override
        public View getChildView(int groupPosition, int childPosition,
                                 boolean isLastChild, View convertView, ViewGroup parent) {
            ItemHolder itemHolder;
            if (convertView == null) {
                convertView = (View) getActivity().getLayoutInflater().from(context).inflate(
                        R.layout.son_send, null);
                itemHolder = new ItemHolder();
                itemHolder.txt1 = (TextView) convertView.findViewById(R.id.name_text);
                itemHolder.txt2 = (TextView) convertView.findViewById(R.id.money_text);
                itemHolder.txt3 = (TextView) convertView.findViewById(R.id.monthday_text);
                convertView.setTag(itemHolder);
            } else {
                itemHolder = (ItemHolder) convertView.getTag();
            }
            itemHolder.txt1.setText(SendBeans.get(groupPosition).get(childPosition).getName());
            itemHolder.txt2.setText("￥"+SendBeans.get(groupPosition).get(childPosition).getMoney()+"元");
            itemHolder.txt3.setText(SendBeans.get(groupPosition).get(childPosition).getMonth()+"/"+SendBeans.get(groupPosition).get(childPosition).getDay());
            return convertView;
        }

        @Override
        public boolean isChildSelectable(int groupPosition, int childPosition) {
            return true;
        }

    }

    class GroupHolder {
        public TextView txt1;
        public TextView txt2;
    }
    class ItemHolder {
        public TextView txt1;
        public TextView txt2;
        public TextView txt3;
    }
}