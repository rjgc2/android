package com.example.youownmeapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.ArrayList;

public class SearchActivity extends AppCompatActivity {
    private EditText input_name;
    private TextView search_result;
    private Button button;
    private ImageButton back_button;
    private String name;
    private StringBuffer string;
    private ArrayList<SendBean> sBeans;
    private ArrayList<ReceiveBean> rBeans;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        getSupportActionBar().hide(); //隐藏标题栏

        input_name = (EditText)findViewById(R.id.input_name);
        search_result = (TextView)findViewById(R.id.search_result);
        button = (Button)findViewById(R.id.button);
        back_button = (ImageButton)findViewById(R.id.tongji_button);

        string = new StringBuffer();

        Intent intent = getIntent();
        //获得传过来的sBeans和rBeans并将其序列化
        sBeans = (ArrayList<SendBean>)intent.getSerializableExtra("sbeans");
        rBeans = (ArrayList<ReceiveBean>)intent.getSerializableExtra("rbeans");

        //给button设置监听事件，显示与输入名字对应的记录
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                name = input_name.getText().toString();
                for(int i=0;i<sBeans.size();i++){
                    if(sBeans.get(i).getName().equals(name)){
                        string.append("随礼："+sBeans.get(i).getName()+"---"+sBeans.get(i).getYear()+sBeans.get(i).getMonth()+"月"+sBeans.get(i).getDay()+"日---￥"+sBeans.get(i).getMoney()+"元").append("\r\n");
                    }
                 }
                for(int j=0;j<rBeans.size();j++){
                    if(name.equals(rBeans.get(j).getName())){
                        string.append("收礼："+rBeans.get(j).getName()+"---"+rBeans.get(j).getYear()+"年"+rBeans.get(j).getMonth()+"月"+rBeans.get(j).getDay()+"日---￥"+rBeans.get(j).getMoney()+"元").append("\r\n");
                    }
                }
                search_result.setText(string);
            }
        });

        back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SearchActivity.this, MainActivity.class);
                startActivity(intent); //点击返回键返回到MainActivity
            }
        });
    }
}