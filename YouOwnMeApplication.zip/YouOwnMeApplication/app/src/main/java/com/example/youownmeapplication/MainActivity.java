package com.example.youownmeapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private FragmentManager fragmentManager;
    private ConstraintLayout view_content;
    private ImageView item1_iv,item2_iv,item3_iv;
    private LinearLayout item1,item2,item3;
    private FloatingActionButton action_button;

    public MainActivity(){
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide(); //隐藏标题栏

        initView();
        fragmentManager = getSupportFragmentManager();
        getSupportFragmentManager().beginTransaction().add(R.id.layout_content,new HomeFragment()).commit();  //MainActivity默认打开HomeFragment

        initListener();
        add();

    }

    private void add(){
        Intent intent=getIntent();
        int id = intent.getIntExtra("id", 0);//获取intent值

        //判断intent里的ID判断添加的是收礼还是随礼记录
        if (id == 1) {
            String year = intent.getStringExtra("addYear");
            String month = intent.getStringExtra("addMonth");
            String day = intent.getStringExtra("addDay");
            String name = intent.getStringExtra("addName");
            String money = intent.getStringExtra("addMoney");

            /*如果输入的内容都不为空，则将该条记录保存到sendDataBank，然后显示SendFragment*/
            if(name.length()>0 && money.length()>0){
                SendDataBank sendDataBank;
                sendDataBank = new SendDataBank(this);
                sendDataBank.Load();
                sendDataBank.getBeans().add(new SendBean(year,month,day,name,money));
                sendDataBank.Save();
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.layout_content,new SendFragment())//设置显示SendFragment
                        .addToBackStack(null)
                        .commit();
            }
            /*如果输入的内容有空的内容，则提示不能为空*/
            else
                Toast.makeText(this,"添加的随礼姓名、金额不能为空！",Toast.LENGTH_SHORT).show();
        }
        else if (id == 2){
            String year = intent.getStringExtra("addYear2");
            String month = intent.getStringExtra("addMonth2");
            String day = intent.getStringExtra("addDay2");
            String name = intent.getStringExtra("addName2");
            String money = intent.getStringExtra("addMoney2");
            String reason = intent.getStringExtra("addReason2");

            /*如果输入的内容都不为空，则将该条记录保存到ReceiveDataBank，然后显示ReceiveFragment*/
            if(name.length()>0 && money.length()>0 && reason.length()>0){
                ReceiveDataBank receiveDataBank;
                receiveDataBank = new ReceiveDataBank(this);
                receiveDataBank.Load();
                receiveDataBank.getBeans().add(new ReceiveBean(year,month,day,name,money,reason));
                receiveDataBank.Save();
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.layout_content,new ReceiveFragment())//设置显示ReceiveFragment
                        .addToBackStack(null)
                        .commit();
            }
            /*如果输入的内容有空的内容，则提示不能为空*/
            else
                Toast.makeText(this,"添加的收礼姓名、金额、原由不能为空！",Toast.LENGTH_SHORT).show();
        }
    }

    /*给三个fragment的图片和add按钮设置监听事件*/
    private void initListener() {
        item1.setOnClickListener(this);
        item2.setOnClickListener(this);
        item3.setOnClickListener(this);
        action_button.setOnClickListener(this);
    }

    private void initView() {
        view_content = (ConstraintLayout) findViewById(R.id.layout_content);
        item1 = (LinearLayout) findViewById(R.id.item1);
        item1_iv = (ImageView) findViewById(R.id.item1_iv);
        item2 = (LinearLayout) findViewById(R.id.item2);
        item2_iv = (ImageView) findViewById(R.id.item2_iv);
        item3 = (LinearLayout) findViewById(R.id.item3);
        item3_iv = (ImageView) findViewById(R.id.item3_iv);
        action_button=(FloatingActionButton)findViewById(R.id.action_button);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            /*点击三个fragment对应的图片就跳转到对应的fragment*/
            case R.id.item1: {
                FragmentTransaction transaction = fragmentManager.beginTransaction();
                transaction.replace(R.id.layout_content,new SendFragment());
                transaction.commit();
                break;
            }
            case R.id.item2: {
                FragmentTransaction transaction = fragmentManager.beginTransaction();
                transaction.replace(R.id.layout_content,new HomeFragment());
                transaction.commit();
                break;
            }
            case R.id.item3: {
                FragmentTransaction transaction = fragmentManager.beginTransaction();
                transaction.replace(R.id.layout_content,new ReceiveFragment());
                transaction.commit();
                break;
            }
            /*如果点击的是添加按钮，则将在HomeFragment选择的日期传给addActivity并跳转到addActivity*/
            case R.id.action_button: {
                Intent intent = new Intent(MainActivity.this, AddActivity.class);
                intent.putExtra("year",HomeFragment.sYear);
                intent.putExtra("month",HomeFragment.sMonth-1); //因为前面在HomeFragment加过1，为了在addactivity中获得点击日期后统一加1，这里先将month-1
                intent.putExtra("day",HomeFragment.sDay);
                startActivity(intent);
                break;
            }
            default:break;
        }
    }
}