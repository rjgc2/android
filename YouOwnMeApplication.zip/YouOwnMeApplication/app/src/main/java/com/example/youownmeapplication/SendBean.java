package com.example.youownmeapplication;

import java.io.Serializable;

public class SendBean implements Serializable,Comparable<SendBean> {
    private String year;
    private String month;
    private String day;
    private String name;
    private String money;

    public SendBean(String year,String month,String day,String name,String money){
        this.year = year;
        this.month = month;
        this.day = day;
        this.name = name;
        this.money = money;
    }

    public String getYear() {
        return year;
    }

    public String getMonth() {
        return month;
    }

    public String getDay() {
        return day;
    }

    public String getName() {
        return name;
    }

    public String getMoney() {
        return money;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setMoney(String money) {
        this.money = money;
    }


    @Override
    public int compareTo(SendBean o) {
        return Integer.parseInt(year);
    }
}
