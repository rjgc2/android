package com.example.youownmeapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;
import com.github.mikephil.charting.interfaces.datasets.IDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;
import java.util.Collections;

public class TongJiActivity extends AppCompatActivity {
    private ImageButton back_button;
    private ArrayList<SendBean> sBeans;
    private ArrayList<ReceiveBean> rBeans;

    private BarChart chart_reveive;
    private BarChart chart_send;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tong_ji);
        getSupportActionBar().hide(); //隐藏标题栏

        Intent intent = getIntent();
        //获得传过来的sBeans和rBeans并将其序列化
        sBeans = (ArrayList<SendBean>)intent.getSerializableExtra("sbeans");
        rBeans = (ArrayList<ReceiveBean>)intent.getSerializableExtra("rbeans");
        back_button = (ImageButton)findViewById(R.id.tongji_button);
        back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TongJiActivity.this, MainActivity.class);
                startActivity(intent); //点击返回键返回到MainActivity
            }
        });
        sendChart();
        receiveChart();
    }
    //sort函数用来将年月去除重复并排序
    public ArrayList<String> sort(ArrayList<String> YearMonth){
        ArrayList<String> str = new ArrayList<>();
        for (int i=0;i<YearMonth.size();i++){
            if(!str.contains(YearMonth.get(i))){
                str.add(YearMonth.get(i));
            }
        }
        Collections.sort(str);
        return str;
    }

    private void sendChart() {
        chart_send = (BarChart)findViewById(R.id.chart_send);
        //设置chart_send的样式
        chart_send.getDescription().setEnabled(false);
        chart_send.setMaxVisibleValueCount(60);
        chart_send.setPinchZoom(false);
        chart_send.setDrawBarShadow(false);
        chart_send.setDrawGridBackground(false);
        chart_send.getAxisRight().setEnabled(false);

        //获得x轴
        XAxis xAxis = chart_send.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);

        chart_send.animateY(2500); //设置动画效果
        chart_send.getLegend().setEnabled(false);

        ArrayList<BarEntry> yVals1 = new ArrayList<BarEntry>();

        ArrayList<String> YearMonth = new ArrayList<>();
        ArrayList<Integer> total = new ArrayList<>(); //用来存放每个不同年月的随礼总额
        /*遍历sBeans，将各个记录的年月存放到YearMonth里*/
        for(int i=0;i<sBeans.size();i++){
            YearMonth.add(sBeans.get(i).getYear()+""+sBeans.get(i).getMonth()+"月");
        }
        ArrayList<String> date = sort(YearMonth); //将YearMonth去除重复并排序后的结果放到date里

        //对date里每一个年月依次进行操作，每一次都遍历sBeans，将其中年月与这一次对应的年月相同的记录的金额加到money里，然后将money加入total
        for(int i = 0; i < date.size(); i++){
            int money = 0;
            for(int j=0;j<sBeans.size();j++){
                String str = sBeans.get(j).getYear()+""+sBeans.get(j).getMonth()+"月";
                if(date.get(i).equals(str)){
                    money = money + Integer.parseInt(sBeans.get(j).getMoney());
                }
            }
            total.add(money);
        }

        //给每个柱设置值为对应的total里的值
        int sum=date.size();
        xAxis.setLabelCount(sum);
        for (int i = 0; i < sum; i++) {
            float val = (float) total.get(i);
            yVals1.add(new BarEntry(i, val));
        }

        BarDataSet set1;
        if (chart_send.getData() != null &&
                chart_send.getData().getDataSetCount() > 0) {
            set1 = (BarDataSet) chart_send.getData().getDataSetByIndex(0);
            set1.setValues(yVals1);
            chart_send.getData().notifyDataChanged();
            chart_send.notifyDataSetChanged();
        } else {
            set1 = new BarDataSet(yVals1, "Data Set");
            set1.setColors(ColorTemplate.VORDIPLOM_COLORS); //设置为多彩
            set1.setDrawValues(false);
            ArrayList<IBarDataSet> dataSets = new ArrayList<>();
            dataSets.add(set1);

            BarData data = new BarData(dataSets);
            chart_send.setData(data);
            chart_send.setFitBars(true);

            //将x轴自定义为date中的年月
            xAxis.setValueFormatter(new IAxisValueFormatter() {
                @Override
                public String getFormattedValue(float value, AxisBase axis) {
                    if (value >= 0) {
                        return date.get((int) value % (date.size()));
                    } else {
                        return "";
                    }
                }
            });
        }
        //这里的作用是将X轴上的文字旋转80度
        chart_send.getXAxis().setLabelRotationAngle(-80);
        chart_send.setScaleYEnabled(false);
        chart_send.setScaleXEnabled(false);
        //每个柱体显示对应的值
        for (IDataSet set : chart_send.getData().getDataSets())
            set.setDrawValues(!set.isDrawValuesEnabled());
        chart_send.invalidate();
    }

    private void receiveChart() {
        chart_reveive = (BarChart)findViewById(R.id.chart_receive);
        //设置chart_reveive的样式
        chart_reveive.getDescription().setEnabled(false);
        chart_reveive.setMaxVisibleValueCount(60);
        chart_reveive.setPinchZoom(false);
        chart_reveive.setDrawBarShadow(false);
        chart_reveive.setDrawGridBackground(false);
        chart_reveive.getAxisRight().setEnabled(false);//隐藏右侧Y轴

        //获得x轴
        XAxis xAxis = chart_reveive.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);

        chart_reveive.animateY(2500); //设置动画效果
        chart_reveive.getLegend().setEnabled(false);
        ArrayList<BarEntry> yVals1 = new ArrayList<BarEntry>();

        ArrayList<String> YearMonth = new ArrayList<>();
        ArrayList<Integer> total = new ArrayList<>();//用来存放每个不同年月的收礼总额
        /*遍历rBeans，将各个记录的年月存放到YearMonth里*/
        for(int i=0;i<rBeans.size();i++){
            YearMonth.add(rBeans.get(i).getYear()+"年"+rBeans.get(i).getMonth()+"月");
        }
        ArrayList<String> date = sort(YearMonth); //将YearMonth去除重复并排序后的结果放到date里

        //对date里每一个年月依次进行操作，每一次都遍历rBeans，将其中年月与这一次对应的年月相同的记录的金额加到money里，然后将money加入total
        for(int i = 0; i < date.size(); i++){
            int money = 0;
            for(int j=0;j<rBeans.size();j++){
                String str = rBeans.get(j).getYear()+"年"+rBeans.get(j).getMonth()+"月";
                if(date.get(i).equals(str)){
                    money = money + Integer.parseInt(rBeans.get(j).getMoney());
                }
            }
            total.add(money);
        }

        //给每个柱设置值为对应的total里的值
        int sum=date.size();
        xAxis.setLabelCount(sum);
        for (int i = 0; i < sum; i++) {
            float val = (float) total.get(i);
            yVals1.add(new BarEntry(i, val));
        }
        BarDataSet set1;
        if (chart_reveive.getData() != null &&
                chart_reveive.getData().getDataSetCount() > 0) {
            set1 = (BarDataSet) chart_reveive.getData().getDataSetByIndex(0);
            set1.setValues(yVals1);
            chart_reveive.getData().notifyDataChanged();
            chart_reveive.notifyDataSetChanged();
        } else {
            set1 = new BarDataSet(yVals1, "Data Set");
            set1.setColors(ColorTemplate.VORDIPLOM_COLORS); //设置为多彩
            set1.setDrawValues(false);
            ArrayList<IBarDataSet> dataSets = new ArrayList<>();
            dataSets.add(set1);

            BarData data = new BarData(dataSets);
            chart_reveive.setData(data);
            chart_reveive.setFitBars(true);

            //将x轴自定义为date中的年月
            xAxis.setValueFormatter(new IAxisValueFormatter() {
                @Override
                public String getFormattedValue(float value, AxisBase axis) {
                    if (value >= 0) {
                        return date.get((int) value % (date.size()));
                    } else {
                        return "";
                    }
                }
            });
        }
        //这里的作用是将X轴上的文字旋转80度
        chart_reveive.getXAxis().setLabelRotationAngle(-80);
        chart_reveive.setScaleYEnabled(false);
        chart_reveive.setScaleXEnabled(false);
        //每个柱体显示对应的值
        for (IDataSet set : chart_reveive.getData().getDataSets())
            set.setDrawValues(!set.isDrawValuesEnabled());
        chart_reveive.invalidate();
    }
}