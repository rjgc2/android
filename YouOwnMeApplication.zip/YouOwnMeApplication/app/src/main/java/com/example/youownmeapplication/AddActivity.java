package com.example.youownmeapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class AddActivity extends AppCompatActivity {
    int mYear, mMonth, mDay;
    EditText name,money,reason;
    Button button_date,button_ok;
    ImageButton back_button;
    TextView dateDisplay;
    final int DATE_DIALOG = 1;
    private RadioGroup radioGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        getSupportActionBar().hide(); //隐藏标题栏

        button_date = (Button) findViewById(R.id.date_button);
        dateDisplay = (TextView) findViewById(R.id.date_text);
        radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        button_ok = (Button)findViewById(R.id.add_ok_button);
        name = (EditText)findViewById(R.id.name_text_edit);
        money = (EditText)findViewById(R.id.money_text_edit);
        reason = (EditText)findViewById(R.id.reason_text_edit);
        back_button = (ImageButton)findViewById(R.id.tongji_button);

        /*获得从MainActivity通过intent传过来的日历选择的年月日，并显示已选择的日期*/
        Intent intent1 = getIntent();
        mYear=intent1.getIntExtra("year",0);
        mMonth=intent1.getIntExtra("month",0);
        mDay=intent1.getIntExtra("day",0);
        dateDisplay.setText(new StringBuffer().append(mYear).append("/").append(mMonth+1).append("/").append(mDay).append(" "));

        /*给按钮设置监听事件*/
        button_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialog(DATE_DIALOG);
            }
        });

        back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AddActivity.this, MainActivity.class);
                startActivity(intent); //点击返回键返回到MainActivity
            }
        });

        button_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int checkedRadioButtonId = radioGroup.getCheckedRadioButtonId();
                Intent intent;

                /*根据点击的单选按钮的ID进行各自的操作，通过intent传值，两种情况分别设置不同的ID为1和2，跳转到MainActivity后根据ID来判断跳转到哪个Fragment*/
                switch (checkedRadioButtonId) {
                    case R.id.send_radio_button:
                        intent = new Intent(AddActivity.this, MainActivity.class);
                        intent.putExtra("id",1);
                        intent.putExtra("addYear",mYear+"年");
                        intent.putExtra("addMonth",mMonth+1+""); //安卓的月是从0开始的，所以month要+1才是正确的月份
                        intent.putExtra("addDay",mDay+"");
                        intent.putExtra("addName",name.getText().toString());
                        intent.putExtra("addMoney",money.getText().toString());
                        startActivity(intent);
                        break;
                    case R.id.receive_radio_button:
                        intent = new Intent(AddActivity.this, MainActivity.class);
                        intent.putExtra("id",2);
                        intent.putExtra("addYear2",mYear+"");
                        intent.putExtra("addMonth2",mMonth+1+""); //安卓的月是从0开始的，所以month要+1才是正确的月份
                        intent.putExtra("addDay2",mDay+"");
                        intent.putExtra("addName2",name.getText().toString());
                        intent.putExtra("addMoney2",money.getText().toString());
                        intent.putExtra("addReason2",reason.getText().toString());
                        startActivity(intent);
                        break;
                }
            }
        });
    }

    /*点击选择日期返回选择的日期*/
    @Override
    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case DATE_DIALOG:
                return new DatePickerDialog(this, mdateListener, mYear, mMonth, mDay);
        }
        return null;
    }

    /*在textview显示选择的日期*/
    public void display() {
        dateDisplay.setText(new StringBuffer().append(mYear).append("/").append(mMonth+1).append("/").append(mDay).append(" "));
    }

    /*点击选择日期后将年月日设置成选择的日期*/
    private DatePickerDialog.OnDateSetListener mdateListener = new DatePickerDialog.OnDateSetListener() {

        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear,
                              int dayOfMonth) {
            mYear = year;
            mMonth = monthOfYear;
            mDay = dayOfMonth;
            display();
        }
    };
}